package com.frauddetector.constants;

public interface FraudDetectorConstants {
	
	public static final String TRAINDATA_CSV="traindata.csv";
	public static final String TRAINDATA_ARFF="traindata.arff";
	
	public static final String TESTDATA_CSV="testdata.csv";
	public static final String TESTDATA_ARFF="testdata.arff";
	
	public static final String FRAUD="Fraud\n";
	public static final String NOTFRAUD="Not Fraud\n";
	
	
}

package com.frauddetector.impl;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import com.frauddetector.constants.FraudDetectorConstants;

import weka.classifiers.functions.Logistic;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.CSVLoader;
import weka.core.converters.ConverterUtils.DataSource;

public class FraudDetectorImpl {

	private static void convertCSVtoARFF(String filename, String destinationfile) throws IOException {

		CSVLoader loader = new CSVLoader();
		loader.setSource(new File(filename));
		Instances data = loader.getDataSet();

		// save ARFF
		BufferedWriter writer = new BufferedWriter(new FileWriter(destinationfile));
		writer.write(data.toString());
		writer.flush();
		writer.close();
	}

	public static String detect() {
		StringBuffer result = new StringBuffer();
		try {
			convertCSVtoARFF(FraudDetectorConstants.TRAINDATA_CSV, FraudDetectorConstants.TRAINDATA_ARFF);
			convertCSVtoARFF(FraudDetectorConstants.TESTDATA_CSV,FraudDetectorConstants.TESTDATA_ARFF);
			DataSource s1 = new DataSource(FraudDetectorConstants.TRAINDATA_ARFF);
			Instances trainDataset = s1.getDataSet();
			trainDataset.setClassIndex(trainDataset.numAttributes() - 1);

			Logistic log = new Logistic();
			log.buildClassifier(trainDataset);

			DataSource s2 = new DataSource(FraudDetectorConstants.TESTDATA_ARFF);
			Instances testDataset = s2.getDataSet();

			testDataset.setClassIndex(testDataset.numAttributes() - 1);

			for (int i = 0; i < testDataset.numInstances(); i++) {
				Instance newinst = testDataset.instance(i);

				double pred = log.classifyInstance(newinst);
				if (pred == 0) {
					result.append(i+1+". "+FraudDetectorConstants.FRAUD);
				} else
					result.append(i+1+". "+FraudDetectorConstants.NOTFRAUD);
			}
			return result.toString();
		} catch (Exception e) {
			e.getMessage();
		}
		return "";
	}

	public static void main(String[] args) {
		String result= detect();
		System.out.println(result);

	}

}
